Description: 
Scans the area surrounding the player and marks metal detector dig spots.

Installation:
Install BepInEx 6 Link here! (Make sure to install x64!)
﻿Extract mcglowsticks.dinkumbetterspotting.dll into (Dinkum Root)/BepInEx/plugins
Configuration:
Rebinding Coming Soon!

Usage:
Just hit Right Alt! Will scan any rendered chunks for dig spots.

Known Bug(s):
Currently the particles will not appear if you are already in range of a dig spot when you scan the area, but when you get into the range of something originally outside of the scan area, the dig spot will show.